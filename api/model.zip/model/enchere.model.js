module.exports = (sequelize, DataTypes, Model) => {

    class Encheres extends Model {}
    Encheres.init({
        // attributs du modèle
        id: {
          type: DataTypes.INTEGER,
          primaryKey: true,
          autoIncrement: true
        },
        montant: {
          type: DataTypes.FLOAT,
          allowNull: false,
          validate: {
            notNull: { msg: "le montant de l'enchère est obligatoire"},
          }
        },
        date: {
            type: DataTypes.DATE,
            allowNull: false,
            defaultValue: sequelize.literal('CURRENT_DATE'),
            validate: {
                notNull: { msg: "le montant de l'enchère est obligatoire"},
            }
        },
        article_id: {
            type: DataTypes.INTEGER,
            allowNull: false,
            validate: {
                notNull: { msg: "L'article ne doit pas être null"}
            },
            references: {
                model: 'articles',
                key: 'id'
              }
        },
        user_id: {
            type: DataTypes.INTEGER,
            allowNull: false,
            validate: {
                notNull: { msg: "L'enchérisseur ne doit pas être null"}
            },
            references: {
                model: 'users',
                key: 'id'
              }
        }
      }, {
        // autres options du modèle
        sequelize, // instance de connexion
        modelName: 'enchere' // nom du modèle
      });
      
      return Encheres;
}