module.exports = (sequelize, DataTypes, Model) => {

    class Images extends Model {}
    Images.init({
        // attributs du modèle
        url: {
          type: DataTypes.STRING,
          primaryKey: true,
        },
        article_id: {
            type: DataTypes.INTEGER,
            allowNull: false,
            validate: {
                notNull: { msg: "L'article ne doit pas être null"}
            },
            references: {
                model: 'articles',
                key: 'id'
              }
        }
      }, {
        // autres options du modèle
        sequelize, // instance de connexion
        modelName: 'image' // nom du modèle
      });
      
      return Images;
}