module.exports = (sequelize, DataTypes, Model) => {

    class Reports extends Model {}

    Reports.init({
        // attributs du modèle
        id: {
          type: DataTypes.INTEGER,
          primaryKey: true,
          autoIncrement: true
        },
        motif: {
          type: DataTypes.STRING,
          allowNull: false,
          validate: {
            isEmpty: { msg: "le motif ne doit pas être vide"},
            notNull: { msg: "le motif est obligatoire"},
          }
        },
        reporter_id: {
            type: DataTypes.INTEGER,
            allowNull: false,
            validate: {
                notNull: { msg: "La personne qui report ne doit pas être null"}
            },
            references: {
                model: 'users',
                key: 'id'
              }
        },
        reported_id: {
            type: DataTypes.INTEGER,
            allowNull: false,
            validate: {
                notNull: { msg: "La personne reportée ne doit pas être null"}
            },
            references: {
                model: 'users',
                key: 'id'
            }
        },
        date: {
            type: DataTypes.DATE,
            allowNull: false,
            defaultValue: sequelize.literal('CURRENT_DATE')
        }
      }, {
        // autres options du modèle
        sequelize, // instance de connexion
        modelName: 'reports' // nom du modèle
      });
      
      return Reports;
}